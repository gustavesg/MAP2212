#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
#Escreva seu nome e numero USP
INFO = {12557438:"Gustavo Soares"}
A = 0.568681411  # A = 0.rg
B = 0.53691739822  # B = 0.cpf
#importa as bibliotecas necessárias
import math
import scipy.stats
import numpy as np
from scipy.stats import qmc
#define função f(x)
def f(x):
    """
    Esta funcao deve receber x e devolver f(x), como especifcado no enunciado
    Escreva o seu codigo nas proximas linhas
    """   
    return  math.exp(-A*x)*math.cos(B*x)

#método crude
def crude(Seed =None):
    #semente
    random.seed(Seed)
    """
    Esta funcao deve retornar a sua estimativa para o valor da integral de f(x)
    usando o metodo crude
    Escreva o seu codigo nas proximas linhas
    """
        
    #inicia  a soma
    soma_f_quasi= 0
        
    #gera sequencia de halton tamanho interactions
    sampler = qmc.Halton(d=1, scramble=False)
    sample = sampler.random(n= 3100)
        
    #incrementa a f dos pontos na soma
    for i in range(3100):
        soma_f_quasi += f(sample[i])
    
    #retorna a média das f 
    return soma_f_quasi/3100 #Retorne sua estimativa


def hit_or_miss(Seed = None):
    random.seed(Seed)
    """
    Esta funcao deve retornar a sua estimativa para o valor da integral de f(x)
    usando o metodo hit or miss
    Escreva o seu codigo nas proximas linhas
    """

    #função indicadora
    def h(x,y):
        if y > f(x): return 0
        else: return 1 
    
    
    #inicia a soma
    soma_hs_quasi = 0
        
    #gera sequencia de halton tamanho interactions pros x e y
    sampler= qmc.Halton(d=2, scramble=False,seed = 38849344330243482)
    sample = sampler.random(n=10100)

        
    for i in range(10100):
        #gera x,y de Halton
        x_halton = sample[i][0]
        y_halton = sample[i][1]
        #incrmenta somas
        soma_hs_quasi += h(x_halton,y_halton)
        
    #devolve a média
    return soma_hs_quasi/10100 #Retorne sua estimativa


def control_variate(Seed = None):
    np.random.seed(Seed)
    random.seed(Seed)
    """
    Esta funcao deve retornar a sua estimativa para o valor da integral de f(x)
    usando o metodo control variate
    Escreva o seu codigo nas proximas linhas
    """
    
    #função auxiliar
    def s(x):
        return -0.5*x + 0.97
    
        
    #inicia a soma 
    soma_quasi = 0
    #gera sequencia de halton tamanho interactions pros x
    sampler_x = qmc.Halton(d=1, scramble=False,seed = 38849344330243482)
    sample_x = sampler_x.random(n=100)
    
    for i in range(100):
        #gera x de halton
        x_quasi = sample_x[i]
        #incrementa as somas
        soma_quasi += (f(x_quasi)-s(x_quasi)+0.72)
        

   
    return float(soma_quasi/100) #Retorne sua estimativa



def importance_sampling(Seed = None):
    
    np.random.seed(Seed)
    """
    Esta funcao deve retornar a sua estimativa para o valor da integral de f(x)
    usando o metodo importance sampling
    Escreva o seu codigo nas proximas linhas
    """
    
    #inversa da função acumulada da distribuição beta
    def G(x):
        return scipy.stats.beta.ppf(x, a = 1.1, b = 1.6)
    
    #distribuição de probabilidade da beta
    def g(x):
        return scipy.stats.beta.pdf(x, a = 1.1, b = 1.6)
    
    
        
    #inicia contador e as somas
    contador = 0
    soma_quasi = 0.0
    
    #gera sequencia de halton tamanho interactions pros x
    sampler_x = qmc.Halton(d=1, scramble=True)
    sample_x = sampler_x.random(n=20000)
        
   
    
    #gera sequencia com distribuição beta a partir da quasi de tamanho interactions
    x_quasi = []
    for i in range(20000):
        x_quasi.append(G(sample_x[i]))
    
    while contador <= 20000-1 :
        
        #incrementa soma        
        soma_quasi +=  (float(f(x_quasi[contador]))/float(g(x_quasi[contador])))
        #adiciona contador
        contador +=1
        
    #retorna média
    return soma_quasi/20000#Retorne sua estimativa
    


def main():
    #Coloque seus testes aqui
    print(crude())
    print(hit_or_miss())
    print(control_variate())
    print(importance_sampling())
    



if __name__ == "__main__":
    main()