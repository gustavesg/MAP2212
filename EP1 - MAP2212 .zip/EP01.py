#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
#Escreva seu nome e numero USP
INFO = {12557438:"Gustavo Soares Gomes"}
def estima_pi(Seed):

    random.seed(Seed) 
    #random.random() gera um numero com distribuicao uniforme em (0,1)
    """
    Esta funcao deve retornar a sua estimativa para o valor de PI
    Escreva o seu codigo nas proximas linhas
    """

    #funcao que diz se o ponto está dentro do circulo ou fora
    def T(x,y):
        
        if (x**2 + y**2) <= 1: return 1
        else: return 0
        
    points_in = 0
    
    for i in range(7247739):
        #escolhe x e y aleatorios
        x_aleatorio = random.random()
        y_aleatorio = random.random()
        
        #atualiza os pontos in
        points_in += T(x_aleatorio,y_aleatorio)
                
    #retorna a estimativa
    return 4*points_in/7247739
    
    

#código para gerar o gráfico de erro
'''import math 
import matplotlib.pyplot as plt

lista_erros = []
lista_i = []
erros_maior_005 = 0
for i in range(100):
    erro = (math.pi - estima_pi(i+67943,7247739))*100/math.pi
    lista_erros.append(erro)
    lista_i.append(i)
    
    if erro > 0.05: erros_maior_005 +=1
    
plt.plot(lista_i, lista_erros)
plt.xlabel('iterações')
plt.ylabel('erro real')
print(erros_maior_005)'''



















